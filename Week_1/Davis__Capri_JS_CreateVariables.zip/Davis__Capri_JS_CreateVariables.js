// The variables to determine if the the guests can ride.
var mininum_age = 10
var mininum_height = 42