function greeting(){
	return "Hello World";
}
var word = greeting( "Hello World" );
console.log(word);

